#!/bin/zsh
sudo docker container exec -it blth "/bin/zsh"