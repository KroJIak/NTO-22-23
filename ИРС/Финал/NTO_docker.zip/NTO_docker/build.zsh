#!/bin/zsh 

sudo docker build --no-cache --pull -t bluetooth  --rm . 
